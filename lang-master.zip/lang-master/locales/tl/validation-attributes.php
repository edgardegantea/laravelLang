<?php

return [
    'attributes' => [
        'image'                   => 'Imahe',
        'result_text_under_image' => 'Resultang teksto sa ilalim ng imahe',
        'short_text'              => 'Maikling teksto',
        'test_description'        => 'Subok na paglalarawan',
        'test_locale'             => 'Wika',
        'test_name'               => 'Subok na pangalan',
    ],
];
